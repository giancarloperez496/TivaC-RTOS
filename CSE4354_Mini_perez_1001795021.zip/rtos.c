/*
 * Giancarlo Perez
 * CSE4354
 * Shell Interface Nano-Project
 * 9/5/24
 */


//Includes
#include <stdio.h>
#include <stdbool.h>
#include "tm4c123gh6pm.h"
#include "clock.h"
#include "gpio.h"
#include "uart0.h"
#include "shell.h"
#include "faults.h"
#include "mm.h"
#include "wait.h"
#include "tasks.h"

//Defines / Globals

extern void setAsp();
extern void setPsp(void* addr); //set the address of the SP, can only be done in privileged i think
extern uint32_t* getPsp();
extern uint32_t* getMsp();
extern void setCtrl(uint32_t mask);

typedef void (*function)(void);
extern uint8_t g_heap[];

void usageFault() {
    int z = 0;
    int x = 1/z;
}

void busFault() { //goes into mem fault
    setCtrl(1);
    NVIC_SYS_HND_CTRL_R &= ~NVIC_SYS_HND_CTRL_BUS;
}

void memFault() {
    setCtrl(1);
    uint32_t* a = 0x20000000;
    //am NOT setting SRAM access window, should fault
    *a = 0xFF;
}

void hardFault() {

    NVIC_SYS_HND_CTRL_R &= ~(NVIC_SYS_HND_CTRL_USAGE | NVIC_SYS_HND_CTRL_BUS);
    usageFault();
}

void pendSv() {
    NVIC_INT_CTRL_R |= NVIC_INT_CTRL_PEND_SV;
}

void sysTick() {
    NVIC_INT_CTRL_R |= NVIC_INT_CTRL_PENDSTSET;
}

//Main

//turn on a bit in reigster to call hard fault with mpu fault.
//TURN ON HARD FAULT

void blink(PORT port, uint8_t pin) {
    setPinValue(port, pin, 1);
    waitMicrosecond(5e5);
    setPinValue(port, pin, 0);
}

void turnOnLeds() {
    setPinValue(BLUE_LED, 1);
    setPinValue(GREEN_LED, 1);
    setPinValue(YELLOW_LED, 1);
    setPinValue(ORANGE_LED, 1);
    setPinValue(RED_LED, 1);
}

void leds() {
    blink(BLUE_LED);
    blink(GREEN_LED);
    blink(YELLOW_LED);
    blink(ORANGE_LED);
    blink(RED_LED);
}

void task() {
    uint32_t* p = malloc_from_heap(1024);
    allowFlashAccess();
    allowPeripheralAccess();
    setupSramAccess();
    uint64_t mask = createNoSramAccessMask();
    addSramAccessWindow(&mask, p, 1024);
    addSramAccessWindow(&mask, 0x20006000, 0x2000);
    initMpu();
    setCtrl(0x1); //DISABLE FOR TESTING ISRs WILL NOT WORK FOR MALLOC PROBABLY
    *p = 30;        //will fault in unprivileged if SRaM accesss not given to top of heap bc stack pointer is in inaccessible SRAM
    /*uint32_t* a = malloc_from_heap(400);
    uint32_t* b = malloc_from_heap(512);
    uint32_t* c = malloc_from_heap(513);
    uint32_t* d = malloc_from_heap(1024);
    uint32_t* e = malloc_from_heap(800);
    uint32_t* f = malloc_from_heap(900);
    free_to_heap(d);
    free_to_heap(e);
    uint32_t* g = malloc_from_heap(1200);*/

    setPinValue(RED_LED, 1);
    uint32_t* good = (uint32_t*)0x20004000+8;
    *good = 100;

    uint32_t* bad = (uint32_t*)0x20001000;
    *bad = 100;
}

void pollButtons() {
    if (getPinValue(PB5)) {
        usageFault();
    }
    else if (getPinValue(PB4)) {
        busFault();
    }
    else if (getPinValue(PB3)) {
        memFault();
    }
    else if (getPinValue(PB2)) {
        hardFault();
    }
    else if (getPinValue(PB1)) {
        pendSv();
    }
    else if (getPinValue(PB0)) {
        sysTick();
    }
}

//TODO
/*
 *
 * apply mask in malloc and free -- not necessary if you just addSramAccessWindow for that ptr
 *
 */
/*   Button Mapping (ONLY WORKS IN PRIV)
 * 6 - Usage Fault
 * 5 - Bus Fault
 * 4 - Mem Fault
 * 3 - Hard Fault
 * 2 - PendSV
 * 1 - sysTick
 */
int main(void) {
    //uint8_t* heapBottom = g_heap;
    //uint8_t* heapTop = g_heap + 0x7000 - 1;

    setPsp(0x20008000);
    setAsp();
    initHw();
    leds();
    task();

    while (1) {
        pollButtons();
        shell();
    }
    return 0;
}
